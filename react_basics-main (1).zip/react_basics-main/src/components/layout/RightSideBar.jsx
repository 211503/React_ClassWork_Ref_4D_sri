import React from "react";

function RightSideBar() {
  return (
    <>
      <aside className="sidebar right-sidebar">
        <h2>Right SideBar</h2>
        <p>Display adds here</p>
      </aside>
    </>
  );
}

export default RightSideBar;
